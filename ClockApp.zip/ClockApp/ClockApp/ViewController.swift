//
//  ViewController.swift
//  ClockApp
//
//  Created by Meagan Williams on 2/5/23.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var startStopButton: UIButton!
    @IBOutlet weak var timeRemaining: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var countdownTimer: Timer = Timer()
    var clockTimer: Timer = Timer()
    var timeLeft: Int?
    var play: AVAudioPlayer?
    
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        /* formatter */
        lazy var formatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "E, d MMM yyyy HH:mm:ss" // or "hh:mm a" if you need to have am or pm symbols
            return formatter
        }()
        
        let now = Date()
        let date = Calendar.current.date(bySettingHour: Calendar.current.component(.hour, from: now), minute: Calendar.current.component(.minute, from: now) + 1, second: 0, of: now)!
        let timer = Timer(fire: date, interval: 60, repeats: true) { _ in
            self.getCurrentTime()
        }
       
        getCurrentTime()
        //change background color depending on AM or PM
        var t = time(nil)
            var tmValue = tm()
            localtime_r(&t, &tmValue)
            let hour = tmValue.tm_hour
            if hour > 18 {
                view.backgroundColor = UIColor.blue
            } else {
                view.backgroundColor = UIColor.yellow
            }
        timeRemaining.text = "Time Remaining:"
       
        
    }
    
   
   
   
   
    @IBAction func timeStart(_ sender: Any) {
        countdownTimer.invalidate()
        if (startStopButton?.currentTitle == "Start Timer / Stop Music") {
            startStopButton.setTitle("Stop Music", for: .normal)
            timeLeft = Int(datePicker.countDownDuration)
            self.countdownTimer = Timer.scheduledTimer(timeInterval: 1.0 , target: self, selector: #selector(startCountdown), userInfo: nil, repeats: true)
            timeRemaining.text = "Time Remaining: \(timerCountdown(Int(datePicker.countDownDuration)))"
        } else {
            play?.stop()
            startStopButton?.setTitle("Start Timer", for: .normal)
        }
    }
    
    
    
    //Functions for app
   
    
    func timerCountdown(_ seconds:Int) -> String {
        let (h, m, s) = secondsToHoursMinutes(seconds)
        return String(format: "%02d:%02d:%02d", h,m,s)
    }
    
    func getCurrentTime() {
        /* formatter */
        lazy var formatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "E, d MMM yyyy HH:mm:ss" // or "hh:mm a" if you need to have am or pm symbols
            return formatter
        }()
        currentTimeLabel.text = formatter.string(from: Date())
    }
    func secondsToHoursMinutes(_ seconds: Int) -> (Int, Int, Int) {
        return ((seconds / 3600, ((seconds % 3600) / 60), ((seconds % 3600) % 60)))
    }
    
    func playAlarm() {
        if let asset = NSDataAsset(name:"alarmsong"){
            do {
                play = try AVAudioPlayer(data:asset.data, fileTypeHint:"wav")
                play?.play()
            } catch let error as NSError{
                print(error.localizedDescription)
            }
        }
    }
    
   @objc func startCountdown() {
        if timeLeft! >= 0 {
            timeRemaining.text = "Time Remaining:  \(timerCountdown(timeLeft!))"
            timeLeft! -= 1
        }
        else {
            countdownTimer.invalidate()
            playAlarm()
        }
    }
    
    
    
    
    
}

